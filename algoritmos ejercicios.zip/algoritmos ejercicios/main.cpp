#include <iostream>
#include "usuario.h"
#include "vehiculo.h"


using namespace std;

int main(int argc, char* argv[] )
{
	vehiculo("pp", 12,"toshiro", 4);


	return 0;
}
