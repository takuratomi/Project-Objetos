#ifndef vehiculo_h_
#define vehiculo_h_

#include <iostream>
#include <string>
#include "usuario.h"

using namespace std;

// clase vehiculo

class vehiculo : public usuario
{
private:
	string placa;  // placa de tipo string
	int ruedas;		// numero de rueda de tipo int

public:
	//  funcion constructora
	vehiculo();  // siempre es necesario
	/* como el vehiculo es una derivada de la clase base usuario hay que darle los parametros
	que va usar la constructora de usuario */
	vehiculo(string name, int numero_identificacion,string placa, int ruedas); 
	
	// funciones para hacer pruebas de la clase vehiculo
	string getMarca();  // retorna como un tipo string el atributo placa
	int getRuedas();	// retorna como un tipo int el artribusto ruedas
	
	~vehiculo(){}
};

#endif