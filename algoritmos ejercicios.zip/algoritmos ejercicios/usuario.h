#ifndef usuario_h_
#define usuario_h_

#include <iostream>
#include <string>

using namespace std;

//clase base
class usuario
{
private:
	string name;  // nombre del usuario
	int numero_id;			// identificacion del usuario

public:

	usuario(); //Siempre es necesario declarar este constructor
	usuario(string name, int numero_id);
    ~usuario();
    
    // estos dos metodos son de pruebas
    string getName(); //retorna el atributo nombre como un string
    int getId();    // retorna el atributo numero_id como un entero
};

#endif