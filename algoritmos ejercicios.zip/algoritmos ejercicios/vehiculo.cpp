#include "vehiculo.h"
#include "usuario.h"

vehiculo::vehiculo(){}

vehiculo::vehiculo(string name, int numero_identificacion, string placa, int ruedas)
{
	usuario(name,numero_identificacion);
	placa=placa;
	ruedas=ruedas;
}
string vehiculo::getMarca()
{
	cout<<placa<<endl;
	return placa;
}

int vehiculo::getRuedas()
{
	cout<<ruedas<<endl;
	return ruedas;
}