#include "usuario.h"

usuario::usuario(){}

usuario::usuario(string name, int numero_id): name(name), numero_id(numero_id) { cout<<"usuario creado"<<endl;}

usuario::~usuario(){}

    
string usuario::getName()
{
	cout<<name<<endl;
	return name;
}
int usuario::getId()
{
	cout<<numero_id<<endl;
	return numero_id;
}
